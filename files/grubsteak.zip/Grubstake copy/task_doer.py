#! /usr/bin/env python
import sys, os, order

def main():
    add_unit_files()
    # print(order.convert_backend_to_frontend("water_lily"))

def add_unit_files():
    path = "camp_info/units_with_counselors.txt"
    f = open(path, "r")
    fl = f.readlines()
    frontend_list = []
    backend_list = []
    counselor_list = []
    for line in fl:
        if ("-") in line:
            unit, counselors = line.split("-")
            frontend_list += [unit]
            backend_list += [unit.lower().replace(" ", "_").replace("\n", "")]
            counselor_list += [counselors.lower().replace("\n", "")]
        else:
            #default is gray
            unit = line
            counselors = "None"
            frontend_list += [unit]
            backend_list += [unit.lower().replace(" ", "_").replace("\n", "")]
            counselor_list += [counselors]

    if not os.path.exists("camp_info/units/"):
        os.makedirs("camp_info/units/")
    else:
        # TODO delete folder, make folder
        pass

    for unit in backend_list:
        unit_file_path = "camp_info/units/" + unit + ".txt"
        if os.path.isfile(unit_file_path):
            # print(unit + " already has a file")
            pass
        else:
            unit_file = open(unit_file_path, "a")
            index = backend_list.index(unit)
            counselors = counselor_list[index].split(", ")
            for counselor in counselors:
                unit_file.write(order.convert_backend_to_frontend(counselor.replace(" ", "_")) + "\n")

if __name__ == '__main__':
    # main should return 0 for success, something else (usually 1) for error.
    sys.exit(main())
